#pragma once
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cstdint>
#include <vector>
#include "math3d.h"
#include "scene.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "h3d", __VA_ARGS__)

struct Mesh {
    GLuint vao = 0, vbo = 0, ebo = 0;
    GLsizei count = 0;
    GLenum mode = GL_TRIANGLES;
};

class Renderer {
public:
    Mesh meshes[SHAPE_COUNT];
    Mesh grid, axisX, axisY, axisZ, wireCube;
    GLuint prog = 0;
    GLint uMVP = -1, uModel = -1, uColor = -1, uUnlit = -1, uLight = -1;

    bool init() {
        const char* vs =
            "#version 300 es\n"
            "layout(location=0) in vec3 aPos;\n"
            "layout(location=1) in vec3 aNormal;\n"
            "uniform mat4 uMVP;\n"
            "uniform mat4 uModel;\n"
            "out vec3 vN;\n"
            "void main(){\n"
            "  vN = transpose(inverse(mat3(uModel))) * aNormal;\n"
            "  gl_Position = uMVP * vec4(aPos,1.0);\n"
            "}\n";
        const char* fs =
            "#version 300 es\n"
            "precision mediump float;\n"
            "in vec3 vN;\n"
            "uniform vec4 uColor;\n"
            "uniform int uUnlit;\n"
            "uniform vec3 uLight;\n"
            "out vec4 oColor;\n"
            "void main(){\n"
            "  if(uUnlit==1){ oColor = uColor; return; }\n"
            "  vec3 n = normalize(vN);\n"
            "  if(!gl_FrontFacing) n = -n;\n"
            "  float d = max(dot(n, normalize(-uLight)), 0.0);\n"
            "  float hemi = 0.55 + 0.45 * n.y;\n"
            "  vec3 c = uColor.rgb * (0.30 * hemi + 0.80 * d);\n"
            "  oColor = vec4(c, uColor.a);\n"
            "}\n";
        GLuint v = compile(GL_VERTEX_SHADER, vs);
        GLuint f = compile(GL_FRAGMENT_SHADER, fs);
        if (!v || !f) return false;
        prog = glCreateProgram();
        glAttachShader(prog, v);
        glAttachShader(prog, f);
        glLinkProgram(prog);
        GLint ok = 0;
        glGetProgramiv(prog, GL_LINK_STATUS, &ok);
        if (!ok) {
            char log[512];
            glGetProgramInfoLog(prog, 512, nullptr, log);
            LOGI("link error: %s", log);
            return false;
        }
        glDeleteShader(v);
        glDeleteShader(f);
        uMVP = glGetUniformLocation(prog, "uMVP");
        uModel = glGetUniformLocation(prog, "uModel");
        uColor = glGetUniformLocation(prog, "uColor");
        uUnlit = glGetUniformLocation(prog, "uUnlit");
        uLight = glGetUniformLocation(prog, "uLight");

        meshes[SHAPE_CUBE] = makeCube();
        meshes[SHAPE_SPHERE] = makeSphere();
        meshes[SHAPE_CYLINDER] = makeCylinder();
        meshes[SHAPE_PLANE] = makePlane();

        std::vector<Vec3> g;
        for (int i = -10; i <= 10; i++) {
            if (i == 0) continue;
            g.push_back(Vec3((float)i, 0, -10)); g.push_back(Vec3((float)i, 0, 10));
            g.push_back(Vec3(-10, 0, (float)i)); g.push_back(Vec3(10, 0, (float)i));
        }
        grid = makeLines(g);
        axisX = makeLines({Vec3(-10, 0, 0), Vec3(10, 0, 0)});
        axisY = makeLines({Vec3(0, 0, 0), Vec3(0, 5, 0)});
        axisZ = makeLines({Vec3(0, 0, -10), Vec3(0, 0, 10)});

        std::vector<Vec3> w;
        Vec3 c[8];
        for (int i = 0; i < 8; i++)
            c[i] = Vec3((i & 1) ? 0.5f : -0.5f, (i & 2) ? 0.5f : -0.5f, (i & 4) ? 0.5f : -0.5f);
        const int e[12][2] = {{0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7}};
        for (auto& ed : e) { w.push_back(c[ed[0]]); w.push_back(c[ed[1]]); }
        wireCube = makeLines(w);
        return true;
    }

    void shutdown() {
        for (auto& m : meshes) destroy(m);
        destroy(grid); destroy(axisX); destroy(axisY); destroy(axisZ); destroy(wireCube);
        if (prog) glDeleteProgram(prog);
        prog = 0;
    }

    void beginFrame(bool playing) {
        if (playing) glClearColor(0.45f, 0.65f, 0.90f, 1);
        else glClearColor(0.13f, 0.15f, 0.19f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glDisable(GL_SCISSOR_TEST);
        glUseProgram(prog);
        glUniform3f(uLight, -0.4f, -1.0f, -0.6f);
    }

    void drawGrid(const Mat4& vp) {
        Mat4 id = Mat4::identity();
        draw(grid, id, vp, 0.30f, 0.33f, 0.38f, true);
        draw(axisX, id, vp, 0.90f, 0.25f, 0.25f, true);
        draw(axisY, id, vp, 0.25f, 0.90f, 0.25f, true);
        draw(axisZ, id, vp, 0.25f, 0.45f, 0.95f, true);
    }

    void drawScene(const Scene& s, const Mat4& vp, int selected) {
        for (size_t i = 0; i < s.objects.size(); i++) {
            const Object& o = s.objects[i];
            float r = o.color[0], g = o.color[1], b = o.color[2];
            if ((int)i == selected) { r = r * 0.65f + 0.35f; g = g * 0.65f + 0.30f; b = b * 0.65f; }
            draw(meshes[o.shape], o.model(), vp, r, g, b, false);
        }
        if (selected >= 0 && selected < (int)s.objects.size()) {
            const Object& o = s.objects[selected];
            glDisable(GL_DEPTH_TEST);
            Object w = o;
            if (o.shape == SHAPE_PLANE) w.scl.y = 0.05f;
            draw(wireCube, w.model(), vp, 1.0f, 0.85f, 0.1f, true);
            glEnable(GL_DEPTH_TEST);
        }
    }

    void draw(const Mesh& m, const Mat4& model, const Mat4& vp, float r, float g, float b, bool unlit) {
        Mat4 mvp = vp * model;
        glUniformMatrix4fv(uMVP, 1, GL_FALSE, mvp.m);
        glUniformMatrix4fv(uModel, 1, GL_FALSE, model.m);
        glUniform4f(uColor, r, g, b, 1.0f);
        glUniform1i(uUnlit, unlit ? 1 : 0);
        glBindVertexArray(m.vao);
        glDrawElements(m.mode, m.count, GL_UNSIGNED_SHORT, nullptr);
        glBindVertexArray(0);
    }

private:
    static GLuint compile(GLenum type, const char* src) {
        GLuint s = glCreateShader(type);
        glShaderSource(s, 1, &src, nullptr);
        glCompileShader(s);
        GLint ok = 0;
        glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
        if (!ok) {
            char log[512];
            glGetShaderInfoLog(s, 512, nullptr, log);
            LOGI("shader error: %s", log);
            return 0;
        }
        return s;
    }

    static void destroy(Mesh& m) {
        if (m.vao) glDeleteVertexArrays(1, &m.vao);
        if (m.vbo) glDeleteBuffers(1, &m.vbo);
        if (m.ebo) glDeleteBuffers(1, &m.ebo);
        m = Mesh();
    }

    static void pushV(std::vector<float>& v, const Vec3& p, const Vec3& n) {
        v.push_back(p.x); v.push_back(p.y); v.push_back(p.z);
        v.push_back(n.x); v.push_back(n.y); v.push_back(n.z);
    }

    static Mesh upload(const std::vector<float>& v, const std::vector<uint16_t>& idx, GLenum mode) {
        Mesh m;
        glGenVertexArrays(1, &m.vao);
        glBindVertexArray(m.vao);
        glGenBuffers(1, &m.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * sizeof(float)), v.data(), GL_STATIC_DRAW);
        glGenBuffers(1, &m.ebo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * sizeof(uint16_t)), idx.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        glBindVertexArray(0);
        m.count = (GLsizei)idx.size();
        m.mode = mode;
        return m;
    }

    static Mesh makeLines(const std::vector<Vec3>& pts) {
        std::vector<float> v;
        std::vector<uint16_t> idx;
        for (size_t i = 0; i < pts.size(); i++) {
            pushV(v, pts[i], Vec3(0, 1, 0));
            idx.push_back((uint16_t)i);
        }
        return upload(v, idx, GL_LINES);
    }

    static Mesh makeCube() {
        std::vector<float> v;
        std::vector<uint16_t> idx;
        const Vec3 N[6] = {Vec3(1,0,0), Vec3(-1,0,0), Vec3(0,1,0), Vec3(0,-1,0), Vec3(0,0,1), Vec3(0,0,-1)};
        const Vec3 U[6] = {Vec3(0,1,0), Vec3(0,1,0), Vec3(0,0,1), Vec3(0,0,1), Vec3(0,1,0), Vec3(0,1,0)};
        const float sa[4] = {-1, 1, 1, -1};
        const float sb[4] = {-1, -1, 1, 1};
        for (int f = 0; f < 6; f++) {
            Vec3 n = N[f], u = U[f], w = cross(n, u);
            uint16_t base = (uint16_t)(v.size() / 6);
            for (int i = 0; i < 4; i++)
                pushV(v, n * 0.5f + u * (sa[i] * 0.5f) + w * (sb[i] * 0.5f), n);
            idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
            idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);
        }
        return upload(v, idx, GL_TRIANGLES);
    }

    static Mesh makePlane() {
        std::vector<float> v;
        std::vector<uint16_t> idx = {0, 1, 2, 0, 2, 3};
        Vec3 n(0, 1, 0);
        pushV(v, Vec3(-0.5f, 0, -0.5f), n);
        pushV(v, Vec3(-0.5f, 0, 0.5f), n);
        pushV(v, Vec3(0.5f, 0, 0.5f), n);
        pushV(v, Vec3(0.5f, 0, -0.5f), n);
        return upload(v, idx, GL_TRIANGLES);
    }

    static Mesh makeSphere() {
        std::vector<float> v;
        std::vector<uint16_t> idx;
        const int rings = 16, sectors = 24;
        const float PI = 3.14159265f;
        for (int r = 0; r <= rings; r++) {
            float th = PI * r / rings;
            for (int s = 0; s <= sectors; s++) {
                float ph = 2 * PI * s / sectors;
                Vec3 n(std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph));
                pushV(v, n * 0.5f, n);
            }
        }
        for (int r = 0; r < rings; r++)
            for (int s = 0; s < sectors; s++) {
                uint16_t a = (uint16_t)(r * (sectors + 1) + s);
                uint16_t b = (uint16_t)(a + sectors + 1);
                idx.push_back(a); idx.push_back(b); idx.push_back(a + 1);
                idx.push_back(a + 1); idx.push_back(b); idx.push_back(b + 1);
            }
        return upload(v, idx, GL_TRIANGLES);
    }

    static Mesh makeCylinder() {
        std::vector<float> v;
        std::vector<uint16_t> idx;
        const int S = 24;
        const float PI = 3.14159265f;
        for (int i = 0; i <= S; i++) {
            float a = 2 * PI * i / S;
            Vec3 n(std::cos(a), 0, std::sin(a));
            pushV(v, Vec3(n.x * 0.5f, 0.5f, n.z * 0.5f), n);
            pushV(v, Vec3(n.x * 0.5f, -0.5f, n.z * 0.5f), n);
        }
        for (int i = 0; i < S; i++) {
            uint16_t t = (uint16_t)(2 * i);
            idx.push_back(t); idx.push_back(t + 1); idx.push_back(t + 2);
            idx.push_back(t + 1); idx.push_back(t + 3); idx.push_back(t + 2);
        }
        for (int sgn = 1; sgn >= -1; sgn -= 2) {
            Vec3 n(0, (float)sgn, 0);
            uint16_t c = (uint16_t)(v.size() / 6);
            pushV(v, Vec3(0, 0.5f * sgn, 0), n);
            uint16_t r0 = (uint16_t)(v.size() / 6);
            for (int i = 0; i <= S; i++) {
                float a = 2 * PI * i / S;
                pushV(v, Vec3(std::cos(a) * 0.5f, 0.5f * sgn, std::sin(a) * 0.5f), n);
            }
            for (int i = 0; i < S; i++) {
                idx.push_back(c); idx.push_back(r0 + i); idx.push_back(r0 + i + 1);
            }
        }
        return upload(v, idx, GL_TRIANGLES);
    }
};
