// h3d - engine 3D para Android (NativeActivity + OpenGL ES 3.0 + Dear ImGui)
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <android/configuration.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <chrono>
#include <string>

#include "imgui.h"
#include "backends/imgui_impl_android.h"
#include "backends/imgui_impl_opengl3.h"
#include "app.h"

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x0040
#endif

struct Ctx {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    bool ready = false;
    App game;
};

static bool initGL(Ctx* c) {
    c->display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(c->display, nullptr, nullptr);
    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_NONE};
    EGLConfig config;
    EGLint n = 0;
    eglChooseConfig(c->display, attribs, &config, 1, &n);
    if (n < 1) { LOGI("sem config EGL ES3"); return false; }
    EGLint fmt;
    eglGetConfigAttrib(c->display, config, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(c->app->window, 0, 0, fmt);
    c->surface = eglCreateWindowSurface(c->display, config, c->app->window, nullptr);
    const EGLint ctxAttr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    c->context = eglCreateContext(c->display, config, EGL_NO_CONTEXT, ctxAttr);
    if (eglMakeCurrent(c->display, c->surface, c->surface, c->context) == EGL_FALSE) return false;
    eglSwapInterval(c->display, 1);

    ImGui_ImplAndroid_Init(c->app->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    if (!c->game.rd.init()) return false;
    c->ready = true;
    return true;
}

static void termGL(Ctx* c) {
    if (c->ready) {
        c->game.rd.shutdown();
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
    }
    c->ready = false;
    if (c->display != EGL_NO_DISPLAY) {
        eglMakeCurrent(c->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (c->context != EGL_NO_CONTEXT) eglDestroyContext(c->display, c->context);
        if (c->surface != EGL_NO_SURFACE) eglDestroySurface(c->display, c->surface);
        eglTerminate(c->display);
    }
    c->display = EGL_NO_DISPLAY;
    c->context = EGL_NO_CONTEXT;
    c->surface = EGL_NO_SURFACE;
    c->game.cancel();
}

static void onCmd(android_app* app, int32_t cmd) {
    Ctx* c = (Ctx*)app->userData;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) initGL(c);
            break;
        case APP_CMD_TERM_WINDOW:
            termGL(c);
            break;
        default:
            break;
    }
}

static int32_t onInput(android_app* app, AInputEvent* e) {
    Ctx* c = (Ctx*)app->userData;
    if (AInputEvent_getType(e) != AINPUT_EVENT_TYPE_MOTION || !c->ready) return 0;
    ImGui_ImplAndroid_HandleInputEvent(e);

    int32_t action = AMotionEvent_getAction(e);
    int act = action & AMOTION_EVENT_ACTION_MASK;
    int idx = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    switch (act) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN:
            c->game.pDown(AMotionEvent_getPointerId(e, idx), AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx));
            break;
        case AMOTION_EVENT_ACTION_MOVE: {
            size_t n = AMotionEvent_getPointerCount(e);
            for (size_t i = 0; i < n; i++)
                c->game.pMove(AMotionEvent_getPointerId(e, i), AMotionEvent_getX(e, i), AMotionEvent_getY(e, i));
            c->game.endMove();
            break;
        }
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP:
            c->game.pUp(AMotionEvent_getPointerId(e, idx), AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx));
            break;
        case AMOTION_EVENT_ACTION_CANCEL:
            c->game.cancel();
            break;
        default:
            break;
    }
    return 1;
}

void android_main(android_app* state) {
    Ctx ctx;
    ctx.app = state;
    state->userData = &ctx;
    state->onAppCmd = onCmd;
    state->onInputEvent = onInput;

    // densidade da tela
    float scale = 2.5f;
    if (state->config) {
        int dens = AConfiguration_getDensity(state->config);
        if (dens > 0 && dens < 1000) scale = dens / 160.0f;
    }
    if (scale < 1.0f) scale = 1.0f;
    if (scale > 4.0f) scale = 4.0f;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImGui::StyleColorsDark();
    ImGui::GetStyle().ScaleAllSizes(scale);
    ImGui::GetStyle().FramePadding = ImVec2(8.0f * scale * 0.6f, 5.0f * scale * 0.6f);
    ImFontConfig fc;
    fc.SizePixels = 13.0f * scale;
    io.Fonts->AddFontDefault(&fc);

    ctx.game.init(std::string(state->activity->internalDataPath) + "/scene.h3d", scale);

    auto last = std::chrono::steady_clock::now();
    while (true) {
        int events;
        android_poll_source* source;
        int timeout = ctx.ready ? 0 : -1;
        while (ALooper_pollOnce(timeout, nullptr, &events, (void**)&source) >= 0) {
            if (source) source->process(state, source);
            if (state->destroyRequested) {
                termGL(&ctx);
                ImGui::DestroyContext();
                return;
            }
            timeout = ctx.ready ? 0 : -1;
        }
        if (state->destroyRequested) {
            termGL(&ctx);
            ImGui::DestroyContext();
            return;
        }
        if (!ctx.ready) continue;

        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - last).count();
        last = now;
        if (dt > 0.1f) dt = 0.1f;

        EGLint w = 0, h = 0;
        eglQuerySurface(ctx.display, ctx.surface, EGL_WIDTH, &w);
        eglQuerySurface(ctx.display, ctx.surface, EGL_HEIGHT, &h);
        glViewport(0, 0, w, h);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();
        ctx.game.update(dt);
        ctx.game.ui();
        ImGui::Render();

        ctx.game.render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        eglSwapBuffers(ctx.display, ctx.surface);
    }
}
