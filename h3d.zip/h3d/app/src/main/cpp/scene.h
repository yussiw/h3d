#pragma once
#include <string>
#include <vector>
#include <fstream>
#include "math3d.h"

enum Shape { SHAPE_CUBE = 0, SHAPE_SPHERE, SHAPE_CYLINDER, SHAPE_PLANE, SHAPE_COUNT };
enum Behavior { BHV_NONE = 0, BHV_SPIN, BHV_BOB };

static const char* kShapeName[SHAPE_COUNT] = {"Cubo", "Esfera", "Cilindro", "Plano"};

struct Object {
    std::string name = "Objeto";
    int shape = SHAPE_CUBE;
    Vec3 pos;
    Vec3 rot;                 // graus (X, Y, Z)
    Vec3 scl = Vec3(1, 1, 1);
    float color[3] = {0.8f, 0.8f, 0.8f};
    int behavior = BHV_NONE;  // usado no modo Play

    Mat4 model() const { return translateM(pos) * rotationM(rot) * scaleM(scl); }
};

struct Scene {
    std::vector<Object> objects;
    int nextId = 1;

    bool save(const std::string& path) const {
        std::ofstream f(path);
        if (!f) return false;
        f.precision(7);
        f << "H3D 1\n";
        for (const Object& o : objects) {
            std::string n = o.name;
            for (char& c : n) if (c == ' ') c = '_';
            if (n.empty()) n = "Objeto";
            f << n << ' ' << o.shape << ' '
              << o.pos.x << ' ' << o.pos.y << ' ' << o.pos.z << ' '
              << o.rot.x << ' ' << o.rot.y << ' ' << o.rot.z << ' '
              << o.scl.x << ' ' << o.scl.y << ' ' << o.scl.z << ' '
              << o.color[0] << ' ' << o.color[1] << ' ' << o.color[2] << ' '
              << o.behavior << '\n';
        }
        return true;
    }

    bool load(const std::string& path) {
        std::ifstream f(path);
        if (!f) return false;
        std::string magic;
        int ver = 0;
        f >> magic >> ver;
        if (magic != "H3D") return false;
        std::vector<Object> out;
        Object o;
        std::string n;
        while (f >> n >> o.shape >> o.pos.x >> o.pos.y >> o.pos.z
                 >> o.rot.x >> o.rot.y >> o.rot.z
                 >> o.scl.x >> o.scl.y >> o.scl.z
                 >> o.color[0] >> o.color[1] >> o.color[2] >> o.behavior) {
            for (char& c : n) if (c == '_') c = ' ';
            o.name = n;
            if (o.shape < 0 || o.shape >= SHAPE_COUNT) o.shape = SHAPE_CUBE;
            out.push_back(o);
        }
        objects = out;
        nextId = (int)objects.size() + 1;
        return true;
    }
};
