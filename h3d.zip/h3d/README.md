# h3d

Engine 3D para Android (C++ / OpenGL ES 3.0 / NativeActivity + Dear ImGui).

## Compilar
1. Suba tudo para o repositório no GitHub (branch main).
2. Aba **Actions** > "Build h3d" (roda sozinho a cada push, ou "Run workflow").
3. Baixe o artefato **h3d-debug-apk**, extraia o zip e instale o .apk.

## Editor
- 1 dedo arrastando: orbitar a câmera
- 2 dedos: pinça = zoom, arrastar = mover a câmera
- Toque em um objeto: seleciona (contorno amarelo). Toque no vazio: desseleciona
- Barra superior: Novo / Salvar / Carregar / Painel / +Cubo +Esfera +Cilindro +Plano / Duplicar / Excluir / PLAY
- Painel direito: lista de objetos e inspetor (Pos, Rot, Esc, Cor, Comportamento)
  (arraste os campos numéricos para alterar valores)

## Play
- Stick flutuante à esquerda: andar (voa na direção que olha)
- Arrastar à direita: olhar
- Objetos com comportamento Girar / Flutuar animam
- "Parar" volta ao editor (a cena não é alterada)

A cena é salva em `scene.h3d` (texto) na pasta interna do app.
