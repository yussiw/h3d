# h3d

Engine 3D para Android (C++17, OpenGL ES 3.0, NativeActivity, Dear ImGui) com editor de cenas,
gerenciador de projetos e scripts em Haxe executados no proprio aparelho (offline).

## Compilar (GitHub Actions)
1. Envie `h3d.zip` para a raiz do repositorio (o workflow extrai o zip e compila).
2. Actions > "Build h3d" > Run workflow. Baixe o artefato `h3d-debug-apk`.
3. O build baixa Dear ImGui e stb_image (precisa de internet no Actions, nao no celular).

## Menu inicial
Lista de projetos: Novo, Abrir, Renomear, Duplicar, Excluir.
Pasta dos projetos: `Android/data/com.yussiw.h3d/files/projects/<nome>/`
  - `scene.h3d`   cena (salva ao tocar em Salvar ou ao voltar ao menu)
  - `scripts/`    arquivos `.hx` (main.hx + quantos quiser)
  - `models/`     modelos `.obj`
  - `textures/`   imagens `.png` `.jpg`
  - `API.txt`     referencia da API de scripts

## Editor
- 1 dedo: orbitar | 2 dedos: zoom e mover | toque: selecionar
- Barra: Menu, Salvar | Sel/Mover/Girar/Escalar (arraste as setas coloridas), Grade | + Adicionar
  (formas, luz, modelos) | Duplicar, Excluir | Painel, Teclado | PLAY
- Painel, por abas: Cena (objetos + inspetor em categorias: Transformar, Material, Fisica,
  Animacao, Comportamento), Ambiente (sol, ceu, sombras, imagem), Scripts, Recursos, Console
- Teclado: abre sozinho ao tocar num campo de texto; se nao abrir, toque no botao "Teclado".
- Realismo: PBR, sombras PCF, luzes de ponto (ate 8), reflexo do ceu, tonemap, neblina, MSAA 4x

## Fisica
Por objeto: Nenhuma / Estatica / Dinamica (massa, quique, atrito, gravidade). Colisores: caixa
alinhada aos eixos (sem rotacao) e esfera. Eventos: `onCollision(a, b)` e gatilhos de animacao.

## Modelos
`.obj` e `.glb` / `.gltf` (malhas, materiais, texturas, esqueleto e animacoes). Nao suporta
compressao Draco/meshopt nem morph targets. Coloque em `models/` e use + Adicionar.

## Animacao (glTF/GLB)
- Padrao: animacao em loop que toca ao dar Play (e como previa no editor).
- Eventos (sem codigo): Ao iniciar, Ao colidir, Apos tempo, Ao tocar - cada um com clipe, atraso,
  velocidade e loop. Ao terminar um clipe unico, volta ao padrao (opcional). Transicao suave.
- Scripts: playAnim, playAnimAfter, stopAnim, setAnimSpeed, animNames..., onAnimEnd, onTap.

## Audio
WAV, MP3, OGG e FLAC (pasta `audio/` do projeto), com mixer por canal (musica, efeitos, ambiente, voz).
- Musica de fundo: aba Ambiente. Sons por objeto (inspetor > Audio): gatilho (iniciar, colidir,
  apos tempo, tocar), volume, tom, variacao aleatoria de tom/volume, atraso, fade in, loop, 3D
  (segue o objeto, distancia minima/maxima) e canal.
- Scripts: `playSound("tiro.ogg", {volume=0.8, pitch=1.2, bus="sfx"})`, `playSoundAt`, `playSoundOn`,
  `playMusic`, `stopSound`, `setBusVolume`..., evento `onSoundEnd(h)`.

## Scripts em Lua 5.4
Lua de verdade (biblioteca oficial embutida), rodando no aparelho, sem internet e sem recompilar.
Escreva `scripts/main.lua` (e outros `.lua`). Funcoes: `start()` e `update(dt)`.
As funcoes da engine (find, setPos, rotate, setColor, uiButton, raycast...) estao em `API.txt`
e na aba Scripts. Projetos antigos com `main.hx` e sem `.lua` ainda rodam no interpretador Haxe.


## Sistemas nativos adicionados: `.h3dm`, easing e primitivas

O editor agora inclui a aba **Modelo 3D**, com ferramentas para criar/editar modelos próprios:
- `easing.h`: 32 curvas de interpolação para keyframes (linear, degrau, famílias In/Out/InOut).
- `primgeo.h`: geração CPU de cubo, esfera e cilindro no formato de geometria interno.
- `h3dm.h`: formato de modelo com hierarquia de ossos, peças, clipes e keyframes; conversão para a estrutura `Gltf` interna.

Na aba **Modelo 3D**, use **Novo**, adicione peças/ossos/clipes e pressione **Salvar**. Os arquivos são gravados em `models/` do projeto ativo, com extensão `.h3dm`. **Carregar** abre um arquivo existente. O formato `.h3dm` é o editor nativo para modelos próprios e curvas de easing.


### Editor de keyframes (atualizacao)
Na aba Modelo 3D > Animacao, agora e possivel selecionar e editar keyframes por osso, alterar
posicao/rotacao/escala e tempo, escolher uma curva de easing por trecho (Linear, Degrau,
Quad In/Out/InOut, Cubic, Sine, Expo, Back, Elastic e Bounce) e excluir keys. O formato nativo `.h3dm` permite criar modelos próprios com curvas personalizadas. O editor glTF/GLB abaixo permite editar diretamente modelos importados e exportar um novo GLB.


### Editor glTF/GLB integrado
Na aba **Modelo 3D**, abra **Editor de arquivos glTF / GLB** para importar um modelo da pasta `models/`.
- Hierarquia de nos: selecione ossos e nos de malha, renomeie e ajuste posicao, rotacao (quaternion) e escala.
- Animacoes: crie clipes do zero, adicione trilhas de posicao/rotacao/escala para os nos e edite, adicione ou exclua keyframes.
- Easing por trecho: Linear, Degrau, Quad/Cubic/Quart/Quint, Sine, Expo, Circ, Back, Elastic e Bounce. Curvas customizadas sao exportadas como 12 amostras LINEAR por trecho para aproximar o movimento no GLB.
- **Exportar GLB** grava um novo arquivo `*_editado.glb`, mantendo os dados originais de malha, materiais e imagens.
- Animacoes glTF existentes com interpolacao STEP/CUBICSPLINE sao preservadas; o menu de easing customizado fica habilitado para trilhas LINEAR.
- Limitacao atual: exportacao direta de GLB requer um unico buffer de geometria. Compressao Draco/meshopt e morph targets continuam sem suporte.
