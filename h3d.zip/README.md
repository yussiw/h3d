# h3d

Engine 3D para Android (C++ / OpenGL ES 3.0 / NativeActivity + Dear ImGui).

## Compilar
1. Suba tudo para o repositório no GitHub (branch main).
2. Aba **Actions** > "Build h3d" (roda sozinho a cada push, ou "Run workflow").
3. Baixe o artefato **h3d-debug-apk**, extraia o zip e instale o .apk.

## Editor
- 1 dedo arrastando: orbitar a câmera
- 2 dedos: pinça = zoom, arrastar = mover a câmera
- Toque em um objeto: seleciona (contorno amarelo). Toque no vazio: desseleciona
- Barra superior: Novo / Salvar / Carregar / Painel / +Cubo +Esfera +Cilindro +Plano / Duplicar / Excluir / PLAY
- Painel direito: lista de objetos e inspetor (Pos, Rot, Esc, Cor, Comportamento)
  (arraste os campos numéricos para alterar valores)

## Play
- Stick flutuante à esquerda: andar (voa na direção que olha)
- Arrastar à direita: olhar
- Objetos com comportamento Girar / Flutuar animam
- "Parar" volta ao editor (a cena não é alterada)

A cena é salva em `scene.h3d` (texto) na pasta interna do app.


## Scripts (`.hx`)

No primeiro início, o h3d cria `scripts/main.hx` dentro do armazenamento privado do app.
O interpretador embutido aceita um subconjunto de Haxe (não é o compilador Haxe oficial):
funções, variáveis, condicionais, loops, arrays, objetos simples e chamadas nativas.

Exemplo:

```haxe
function onCreate() {
    trace("Jogo iniciado");
    trace("Objetos: " + getObjectCount());
}

function onUpdate(dt) {
    // O índice começa em zero e segue a ordem da lista de objetos da cena.
    setObjectRotation(1, 0, getTime() * 90, 0);
}

function onDestroy() {
    trace("Jogo encerrado");
}
```

Callbacks disponíveis: `onCreate()`, `onUpdate(dt)` e `onDestroy()`.

Nativas de cena: `getObjectCount()`, `getTime()`, `getObjectPosition(index)`,
`setObjectPosition(index, x, y, z)`, `setObjectRotation(index, x, y, z)` e
`setObjectScale(index, x, y, z)`. `getObjectPosition` retorna um objeto com `x`, `y` e `z`.

Nativas de arquivos: `fs.exists(path)`, `fs.isDir(path)`, `fs.list(path)`,
`fs.mkdir(path)`, `fs.read(path)`, `fs.write(path, content)` e `fs.remove(path)`. `fs.list` retorna nomes de arquivos e nomes de pastas com `/` no final.
Todos os caminhos são relativos à pasta privada do projeto; caminhos absolutos,
`..`, `.` e barras invertidas são recusados. `fs.remove` não permite remover a raiz
nem a pasta `scripts`.

## Build Android

O workflow do GitHub Actions compila o projeto diretamente na raiz do repositório.
Não é necessário manter um `h3d.zip` dentro do repositório. O APK de debug aparece
em `app/build/outputs/apk/debug/` e também é publicado como artefato da Action.
A primeira configuração CMake baixa Dear ImGui do GitHub, portanto o runner precisa
de acesso à internet.
