# h3d

Engine 3D para Android (C++17, OpenGL ES 3.0, NativeActivity, Dear ImGui) com editor de cenas,
gerenciador de projetos e scripts em Haxe executados no proprio aparelho (offline).

## Compilar (GitHub Actions)
1. Envie `h3d.zip` para a raiz do repositorio (o workflow extrai o zip e compila).
2. Actions > "Build h3d" > Run workflow. Baixe o artefato `h3d-debug-apk`.
3. O build baixa Dear ImGui e stb_image (precisa de internet no Actions, nao no celular).

## Menu inicial
Lista de projetos: Novo, Abrir, Renomear, Duplicar, Excluir.
Pasta dos projetos: `Android/data/com.yussiw.h3d/files/projects/<nome>/`
  - `scene.h3d`   cena (salva ao tocar em Salvar ou ao voltar ao menu)
  - `scripts/`    arquivos `.hx` (main.hx + quantos quiser)
  - `models/`     modelos `.obj`
  - `textures/`   imagens `.png` `.jpg`
  - `API.txt`     referencia da API de scripts

## Editor
- 1 dedo: orbitar | 2 dedos: zoom e mover | toque: selecionar
- Sel / Mover / Girar / Escalar: arraste as setas coloridas do objeto (Grade = encaixe)
- Abas: Cena (objetos, inspetor, materiais), Ambiente (sol, ceu, sombras, neblina, exposicao),
  Scripts (editor Haxe + console + API), Recursos (modelos e texturas)
- Realismo: PBR (metalico/rugosidade), sombras com PCF, luzes de ponto (ate 8), reflexo do ceu,
  tonemap, neblina, MSAA 4x

## Scripts em Lua 5.4
Lua de verdade (biblioteca oficial embutida), rodando no aparelho, sem internet e sem recompilar.
Escreva `scripts/main.lua` (e outros `.lua`). Funcoes: `start()` e `update(dt)`.
As funcoes da engine (find, setPos, rotate, setColor, uiButton, raycast...) estao em `API.txt`
e na aba Scripts. Projetos antigos com `main.hx` e sem `.lua` ainda rodam no interpretador Haxe.
