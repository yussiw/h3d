#pragma once
#include <string>
#include <vector>
#include <fstream>
#include "math3d.h"

enum Shape { SHAPE_CUBE = 0, SHAPE_SPHERE, SHAPE_CYLINDER, SHAPE_PLANE, SHAPE_MODEL, SHAPE_LIGHT, SHAPE_COUNT };
enum Behavior { BHV_NONE = 0, BHV_SPIN, BHV_BOB };

static const char* kShapeName[SHAPE_COUNT] = {"Cubo", "Esfera", "Cilindro", "Plano", "Modelo", "Luz"};

// Ambiente / iluminacao / realismo
struct Env {
    float sunYaw = 40.0f, sunPitch = -50.0f;   // graus (pitch negativo = sol apontando para baixo)
    float sunColor[3] = {1.0f, 0.95f, 0.85f};
    float sunIntensity = 3.0f;
    float ambient = 0.8f;
    float skyTop[3] = {0.22f, 0.42f, 0.80f};
    float skyHorizon[3] = {0.70f, 0.82f, 0.95f};
    float ground[3] = {0.28f, 0.27f, 0.25f};
    float fog = 0.0f;
    float exposure = 1.0f;
    int tonemap = 1;
    int shadows = 1;
    int shadowSize = 1024;
    float shadowSoft = 1.5f;
    float shadowRange = 25.0f;
};

struct Object {
    int uid = 0;
    std::string name = "Objeto";
    int shape = SHAPE_CUBE;
    std::string model;     // arquivo .obj (SHAPE_MODEL), na pasta models/
    std::string texture;   // imagem na pasta textures/
    Vec3 pos;
    Vec3 rot;              // graus (X, Y, Z)
    Vec3 scl = Vec3(1, 1, 1);
    float color[3] = {0.8f, 0.8f, 0.8f};
    float metallic = 0.0f;
    float roughness = 0.5f;
    float emissive[3] = {0, 0, 0};
    float emissiveStrength = 0.0f;
    float tile[2] = {1, 1};
    int behavior = BHV_NONE;
    bool castShadow = true;
    bool visible = true;
    float intensity = 15.0f;  // luz
    float range = 12.0f;      // luz

    Mat4 matrix() const { return translateM(pos) * rotationM(rot) * scaleM(scl); }
};

static inline std::string encTok(const std::string& s) {
    if (s.empty()) return "\x02";
    std::string o = s;
    for (char& c : o) if (c == ' ' || c == '\t' || c == '\n' || c == '\r') c = '\x01';
    return o;
}
static inline std::string decTok(const std::string& s) {
    if (s == "\x02") return "";
    std::string o = s;
    for (char& c : o) if (c == '\x01') c = ' ';
    return o;
}

struct Scene {
    std::vector<Object> objects;
    Env env;
    int nextId = 1;    // contador para nomes
    int nextUid = 1;   // id unico

    int add(const Object& o) {
        Object c = o;
        c.uid = nextUid++;
        objects.push_back(c);
        return c.uid;
    }

    bool save(const std::string& path) const {
        std::ofstream f(path);
        if (!f) return false;
        f.precision(7);
        f << "H3D 2\n";
        const Env& e = env;
        f << "env " << e.sunYaw << ' ' << e.sunPitch << ' '
          << e.sunColor[0] << ' ' << e.sunColor[1] << ' ' << e.sunColor[2] << ' ' << e.sunIntensity << ' '
          << e.ambient << ' '
          << e.skyTop[0] << ' ' << e.skyTop[1] << ' ' << e.skyTop[2] << ' '
          << e.skyHorizon[0] << ' ' << e.skyHorizon[1] << ' ' << e.skyHorizon[2] << ' '
          << e.ground[0] << ' ' << e.ground[1] << ' ' << e.ground[2] << ' '
          << e.fog << ' ' << e.exposure << ' ' << e.tonemap << ' ' << e.shadows << ' '
          << e.shadowSize << ' ' << e.shadowSoft << ' ' << e.shadowRange << '\n';
        for (const Object& o : objects) {
            f << "obj " << encTok(o.name) << ' ' << o.shape << ' ' << encTok(o.model) << ' ' << encTok(o.texture) << ' '
              << o.pos.x << ' ' << o.pos.y << ' ' << o.pos.z << ' '
              << o.rot.x << ' ' << o.rot.y << ' ' << o.rot.z << ' '
              << o.scl.x << ' ' << o.scl.y << ' ' << o.scl.z << ' '
              << o.color[0] << ' ' << o.color[1] << ' ' << o.color[2] << ' '
              << o.metallic << ' ' << o.roughness << ' '
              << o.emissive[0] << ' ' << o.emissive[1] << ' ' << o.emissive[2] << ' ' << o.emissiveStrength << ' '
              << o.tile[0] << ' ' << o.tile[1] << ' '
              << o.behavior << ' ' << (o.castShadow ? 1 : 0) << ' ' << (o.visible ? 1 : 0) << ' '
              << o.intensity << ' ' << o.range << '\n';
        }
        return (bool)f;
    }

    bool load(const std::string& path) {
        std::ifstream f(path);
        if (!f) return false;
        std::string magic;
        int ver = 0;
        f >> magic >> ver;
        if (magic != "H3D" || ver != 2) return false;
        Env e;
        std::vector<Object> out;
        std::string tag;
        while (f >> tag) {
            if (tag == "env") {
                f >> e.sunYaw >> e.sunPitch >> e.sunColor[0] >> e.sunColor[1] >> e.sunColor[2] >> e.sunIntensity
                  >> e.ambient >> e.skyTop[0] >> e.skyTop[1] >> e.skyTop[2]
                  >> e.skyHorizon[0] >> e.skyHorizon[1] >> e.skyHorizon[2]
                  >> e.ground[0] >> e.ground[1] >> e.ground[2]
                  >> e.fog >> e.exposure >> e.tonemap >> e.shadows >> e.shadowSize >> e.shadowSoft >> e.shadowRange;
            } else if (tag == "obj") {
                Object o;
                std::string n, m, t;
                int cs = 1, vis = 1;
                f >> n >> o.shape >> m >> t
                  >> o.pos.x >> o.pos.y >> o.pos.z >> o.rot.x >> o.rot.y >> o.rot.z
                  >> o.scl.x >> o.scl.y >> o.scl.z >> o.color[0] >> o.color[1] >> o.color[2]
                  >> o.metallic >> o.roughness >> o.emissive[0] >> o.emissive[1] >> o.emissive[2] >> o.emissiveStrength
                  >> o.tile[0] >> o.tile[1] >> o.behavior >> cs >> vis >> o.intensity >> o.range;
                if (!f) break;
                o.name = decTok(n);
                o.model = decTok(m);
                o.texture = decTok(t);
                o.castShadow = cs != 0;
                o.visible = vis != 0;
                if (o.shape < 0 || o.shape >= SHAPE_COUNT) o.shape = SHAPE_CUBE;
                o.uid = (int)out.size() + 1;
                out.push_back(o);
            } else {
                std::string skip;
                std::getline(f, skip);
            }
        }
        objects = out;
        env = e;
        nextUid = (int)objects.size() + 1;
        nextId = (int)objects.size() + 1;
        return true;
    }
};
