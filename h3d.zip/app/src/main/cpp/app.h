#pragma once
#include <string>
#include <vector>
#include <array>
#include <cmath>
#include <cstdio>
#include <android/log.h>
#include <fstream>
#include "fsutil.h"
#include "script.h"
#include "imgui.h"
#include "math3d.h"
#include "scene.h"
#include "renderer.h"

struct Ptr {
    bool active = false, ui = false;
    float x = 0, y = 0, dx = 0, dy = 0, sx = 0, sy = 0, moved = 0;
};

class App {
public:
    Scene scene, play;
    Renderer rd;
    int selected = -1;
    bool playing = false;
    float time = 0;
    int W = 1, H = 1;
    float dp = 2.5f;  // densidade (dpi/160)

    // câmera orbital do editor
    float yaw = 0.7f, pitch = 0.5f, dist = 9.0f;
    Vec3 target = Vec3(0, 0.5f, 0);

    // jogador (modo Play)
    Vec3 pPos;
    float pYaw = 0, pPitch = 0;
    float stickX = 0, stickY = 0;

    Ptr ptr[10];
    bool multi = false;
    bool showPanel = true;
    bool wantPlay = false, wantStop = false;
    float barH = 0;
    std::string status, savePath;
    std::string projectDir, scriptsDir, mainScriptPath;
    hx::Interp script;
    bool scriptLoaded = false;
    std::vector<std::array<float, 4>> rects;

    void init(const std::string& path, float density) {
        savePath = path;
        dp = density;
        const size_t slash = savePath.find_last_of('/');
        projectDir = slash == std::string::npos ? "." : savePath.substr(0, slash);
        scriptsDir = projectDir + "/scripts";
        mainScriptPath = scriptsDir + "/main.hx";
        fsu::mkdirs(scriptsDir);
        if (!fsu::exists(mainScriptPath)) {
            const std::string starter =
                "// Script principal do h3d (subconjunto Haxe)\n"
                "function onCreate() {\n"
                "    trace(\"Script iniciado!\");\n"
                "}\n\n"
                "function onUpdate(dt) {\n"
                "    // Atualizado a cada frame durante o Play.\n"
                "}\n";
            fsu::writeFile(mainScriptPath, starter);
        }
        if (!scene.load(savePath)) defaultScene();
    }

    void defaultScene() {
        scene.objects.clear();
        Object ground; ground.name = "Chao"; ground.shape = SHAPE_PLANE;
        ground.scl = Vec3(20, 1, 20); ground.color[0] = 0.35f; ground.color[1] = 0.6f; ground.color[2] = 0.35f;
        scene.objects.push_back(ground);
        Object a; a.name = "Cubo 1"; a.shape = SHAPE_CUBE; a.pos = Vec3(-2, 0.5f, 0);
        a.color[0] = 0.9f; a.color[1] = 0.3f; a.color[2] = 0.3f; a.behavior = BHV_SPIN;
        scene.objects.push_back(a);
        Object b; b.name = "Esfera 1"; b.shape = SHAPE_SPHERE; b.pos = Vec3(0, 0.5f, 0);
        b.color[0] = 0.3f; b.color[1] = 0.5f; b.color[2] = 0.95f; b.behavior = BHV_BOB;
        scene.objects.push_back(b);
        Object c; c.name = "Cilindro 1"; c.shape = SHAPE_CYLINDER; c.pos = Vec3(2, 0.5f, 0);
        c.color[0] = 0.95f; c.color[1] = 0.8f; c.color[2] = 0.2f;
        scene.objects.push_back(c);
        scene.nextId = 2;
        selected = -1;
    }

    // ---------- câmera ----------
    void camBasis(Vec3& eye, Vec3& fwd, Vec3& right, Vec3& up) const {
        if (playing) {
            float cp = std::cos(pPitch);
            fwd = Vec3(std::sin(pYaw) * cp, std::sin(pPitch), -std::cos(pYaw) * cp);
            eye = pPos;
        } else {
            eye = target + Vec3(std::cos(pitch) * std::sin(yaw), std::sin(pitch), std::cos(pitch) * std::cos(yaw)) * dist;
            fwd = normalize(target - eye);
        }
        right = normalize(cross(fwd, Vec3(0, 1, 0)));
        up = cross(right, fwd);
    }

    Mat4 viewProj() const {
        Vec3 eye, fwd, right, up;
        camBasis(eye, fwd, right, up);
        float aspect = (float)W / (float)(H > 0 ? H : 1);
        return perspectiveM(60.0f, aspect, 0.1f, 300.0f) * lookAtM(eye, eye + fwd, Vec3(0, 1, 0));
    }

    // ---------- scripts Haxe (.hx) ----------
    std::string scriptPath(const std::string& relative) const {
        // Scripts só podem acessar caminhos relativos dentro da pasta do projeto.
        if (relative.empty() || relative[0] == '/' || relative.find('\\') != std::string::npos)
            return "";
        size_t begin = 0;
        while (begin <= relative.size()) {
            size_t end = relative.find('/', begin);
            if (end == std::string::npos) end = relative.size();
            const std::string part = relative.substr(begin, end - begin);
            if (part == ".." || part == "." || part.empty()) return "";
            if (end == relative.size()) break;
            begin = end + 1;
        }
        return projectDir + "/" + relative;
    }

    void setupScriptAPI() {
        script.natives["trace"] = [this](hx::Args& a) {
            std::string msg;
            for (size_t i = 0; i < a.size(); ++i) {
                if (i) msg += " ";
                msg += hx::toStr(a[i]);
            }
            __android_log_print(ANDROID_LOG_INFO, "h3d-script", "%s", msg.c_str());
            status = msg;
            return hx::Value();
        };
        script.natives["getObjectCount"] = [this](hx::Args&) {
            return hx::Value::num((double)play.objects.size());
        };
        script.natives["setObjectPosition"] = [this](hx::Args& a) {
            if (a.size() >= 4 && a[0].t == hx::Value::Num) {
                int i = (int)a[0].n;
                if (i >= 0 && i < (int)play.objects.size() && a[1].t == hx::Value::Num && a[2].t == hx::Value::Num && a[3].t == hx::Value::Num)
                    play.objects[i].pos = Vec3((float)a[1].n, (float)a[2].n, (float)a[3].n);
            }
            return hx::Value();
        };
        script.natives["setObjectRotation"] = [this](hx::Args& a) {
            if (a.size() >= 4 && a[0].t == hx::Value::Num) {
                int i = (int)a[0].n;
                if (i >= 0 && i < (int)play.objects.size() && a[1].t == hx::Value::Num && a[2].t == hx::Value::Num && a[3].t == hx::Value::Num)
                    play.objects[i].rot = Vec3((float)a[1].n, (float)a[2].n, (float)a[3].n);
            }
            return hx::Value();
        };
        script.natives["setObjectScale"] = [this](hx::Args& a) {
            if (a.size() >= 4 && a[0].t == hx::Value::Num) {
                int i = (int)a[0].n;
                if (i >= 0 && i < (int)play.objects.size() && a[1].t == hx::Value::Num && a[2].t == hx::Value::Num && a[3].t == hx::Value::Num)
                    play.objects[i].scl = Vec3((float)a[1].n, (float)a[2].n, (float)a[3].n);
            }
            return hx::Value();
        };
        script.natives["getObjectPosition"] = [this](hx::Args& a) {
            if (a.empty() || a[0].t != hx::Value::Num) return hx::Value();
            int i = (int)a[0].n;
            if (i < 0 || i >= (int)play.objects.size()) return hx::Value();
            const Vec3& p = play.objects[i].pos;
            hx::Value out = hx::Value::obj();
            (*out.o)["x"] = hx::Value::num(p.x);
            (*out.o)["y"] = hx::Value::num(p.y);
            (*out.o)["z"] = hx::Value::num(p.z);
            return out;
        };
        script.natives["getTime"] = [this](hx::Args&) { return hx::Value::num(time); };
        script.natives["fs.isDir"] = [this](hx::Args& a) {
            if (a.empty()) return hx::Value::boolean(false);
            std::string p = scriptPath(hx::toStr(a[0]));
            return hx::Value::boolean(!p.empty() && fsu::isDir(p));
        };
        script.natives["fs.mkdir"] = [this](hx::Args& a) {
            if (a.empty()) return hx::Value::boolean(false);
            std::string p = scriptPath(hx::toStr(a[0]));
            return hx::Value::boolean(!p.empty() && fsu::mkdirs(p));
        };
        script.natives["fs.remove"] = [this](hx::Args& a) {
            if (a.empty()) return hx::Value::boolean(false);
            std::string p = scriptPath(hx::toStr(a[0]));
            if (p.empty() || p == projectDir || p == scriptsDir) return hx::Value::boolean(false);
            if (!fsu::exists(p)) return hx::Value::boolean(false);
            fsu::removeAll(p);
            return hx::Value::boolean(!fsu::exists(p));
        };
        script.natives["fs.exists"] = [this](hx::Args& a) {
            if (a.empty()) return hx::Value::boolean(false);
            std::string p = scriptPath(hx::toStr(a[0]));
            return hx::Value::boolean(!p.empty() && fsu::exists(p));
        };
        script.natives["fs.read"] = [this](hx::Args& a) {
            std::string data, p = a.empty() ? "" : scriptPath(hx::toStr(a[0]));
            if (p.empty() || !fsu::readFile(p, data)) return hx::Value();
            return hx::Value::str(data);
        };
        script.natives["fs.write"] = [this](hx::Args& a) {
            if (a.size() < 2) return hx::Value::boolean(false);
            std::string p = scriptPath(hx::toStr(a[0]));
            if (p.empty()) return hx::Value::boolean(false);
            size_t slash = p.find_last_of('/');
            if (slash != std::string::npos) fsu::mkdirs(p.substr(0, slash));
            return hx::Value::boolean(fsu::writeFile(p, hx::toStr(a[1])));
        };
        script.natives["fs.list"] = [this](hx::Args& a) {
            std::string p = a.empty() ? "" : scriptPath(hx::toStr(a[0]));
            hx::Value out = hx::Value::arr();
            if (p.empty()) return out;
            for (const std::string& name : fsu::list(p, false)) out.a->push_back(hx::Value::str(name));
            for (const std::string& name : fsu::list(p, true)) out.a->push_back(hx::Value::str(name + "/"));
            return out;
        };
    }

    bool loadGameScript() {
        script = hx::Interp();
        setupScriptAPI();
        std::string source, error;
        if (!fsu::readFile(mainScriptPath, source)) {
            status = "Nao foi possivel ler scripts/main.hx";
            scriptLoaded = false;
            return false;
        }
        if (source.size() > 256 * 1024) {
            status = "Script muito grande (limite: 256 KB)";
            scriptLoaded = false;
            return false;
        }
        if (!script.load(source, mainScriptPath, error)) {
            status = "Erro no script: " + error;
            scriptLoaded = false;
            return false;
        }
        scriptLoaded = true;
        if (script.has("onCreate") && !script.call("onCreate", {}, error)) {
            status = "Erro onCreate: " + error;
            scriptLoaded = false;
            return false;
        }
        return true;
    }

    // ---------- lógica ----------
    void update(float dt) {
        time += dt;
        if (!playing) return;
        for (size_t i = 0; i < play.objects.size() && i < scene.objects.size(); i++) {
            Object& o = play.objects[i];
            const Object& b = scene.objects[i];
            if (b.behavior == BHV_SPIN) o.rot.y = b.rot.y + time * 90.0f;
            else if (b.behavior == BHV_BOB) o.pos.y = b.pos.y + std::sin(time * 2.0f) * 0.5f;
        }
        // O script roda depois dos comportamentos nativos para poder sobrescrevê-los.
        if (scriptLoaded && script.has("onUpdate")) {
            std::string error;
            if (!script.call("onUpdate", {hx::Value::num(dt)}, error)) {
                status = "Erro onUpdate: " + error;
                scriptLoaded = false;
            }
        }
        Vec3 eye, fwd, right, up;
        camBasis(eye, fwd, right, up);
        Vec3 mv = fwd * (-stickY) + right * stickX;
        pPos += mv * (4.0f * dt);
    }

    void startPlay() {
        Vec3 eye, fwd, right, up;
        camBasis(eye, fwd, right, up);
        pPos = eye;
        pYaw = std::atan2(fwd.x, -fwd.z);
        pPitch = std::asin(std::max(-1.0f, std::min(1.0f, fwd.y)));
        play = scene;
        time = 0;
        stickX = stickY = 0;
        playing = true;
        scriptLoaded = false;
        loadGameScript();
    }

    void stopPlay() {
        if (scriptLoaded && script.has("onDestroy")) {
            std::string error;
            if (!script.call("onDestroy", {}, error)) status = "Erro onDestroy: " + error;
        }
        scriptLoaded = false;
        playing = false;
        stickX = stickY = 0;
    }

    void addObject(int shape) {
        Object o;
        o.shape = shape;
        o.name = std::string(kShapeName[shape]) + " " + std::to_string(scene.nextId++);
        o.pos = Vec3(std::round(target.x), shape == SHAPE_PLANE ? 0.0f : 0.5f, std::round(target.z));
        if (shape == SHAPE_PLANE) { o.scl = Vec3(4, 1, 4); o.color[0] = 0.5f; o.color[1] = 0.5f; o.color[2] = 0.55f; }
        else { o.color[0] = 0.8f; o.color[1] = 0.8f; o.color[2] = 0.85f; }
        scene.objects.push_back(o);
        selected = (int)scene.objects.size() - 1;
    }

    void duplicateSelected() {
        if (selected < 0 || selected >= (int)scene.objects.size()) return;
        Object o = scene.objects[selected];
        o.name += " copia";
        o.pos.x += 1.0f;
        scene.objects.push_back(o);
        selected = (int)scene.objects.size() - 1;
    }

    void deleteSelected() {
        if (selected < 0 || selected >= (int)scene.objects.size()) return;
        scene.objects.erase(scene.objects.begin() + selected);
        selected = -1;
    }

    // ---------- seleção (raycast) ----------
    static bool rayBox(const Vec3& o, const Vec3& d, const Vec3& h, float& t) {
        float oo[3] = {o.x, o.y, o.z}, dd[3] = {d.x, d.y, d.z}, hh[3] = {h.x, h.y, h.z};
        float tmin = -1e30f, tmax = 1e30f;
        for (int i = 0; i < 3; i++) {
            if (std::fabs(dd[i]) < 1e-8f) {
                if (oo[i] < -hh[i] || oo[i] > hh[i]) return false;
            } else {
                float t1 = (-hh[i] - oo[i]) / dd[i], t2 = (hh[i] - oo[i]) / dd[i];
                if (t1 > t2) std::swap(t1, t2);
                tmin = std::max(tmin, t1);
                tmax = std::min(tmax, t2);
                if (tmin > tmax) return false;
            }
        }
        if (tmax < 0) return false;
        t = tmin >= 0 ? tmin : tmax;
        return true;
    }

    static bool rayObject(const Object& ob, const Vec3& ro, const Vec3& rd, float& t) {
        Mat4 R = rotationM(ob.rot);
        Vec3 s(std::max(ob.scl.x, 0.001f), std::max(ob.scl.y, 0.001f), std::max(ob.scl.z, 0.001f));
        Vec3 lo = mulTransposed3(R, ro - ob.pos);
        Vec3 ld = mulTransposed3(R, rd);
        lo = Vec3(lo.x / s.x, lo.y / s.y, lo.z / s.z);
        ld = Vec3(ld.x / s.x, ld.y / s.y, ld.z / s.z);
        if (ob.shape == SHAPE_SPHERE) {
            float a = dot(ld, ld), b = 2 * dot(lo, ld), c = dot(lo, lo) - 0.25f;
            float disc = b * b - 4 * a * c;
            if (disc < 0) return false;
            float sq = std::sqrt(disc);
            float t1 = (-b - sq) / (2 * a), t2 = (-b + sq) / (2 * a);
            if (t2 < 0) return false;
            t = t1 >= 0 ? t1 : t2;
            return true;
        }
        Vec3 h = ob.shape == SHAPE_PLANE ? Vec3(0.5f, 0.03f, 0.5f) : Vec3(0.5f, 0.5f, 0.5f);
        return rayBox(lo, ld, h, t);
    }

    void pick(float px, float py) {
        Vec3 eye, fwd, right, up;
        camBasis(eye, fwd, right, up);
        float th = std::tan(30.0f * kDeg2Rad);
        float aspect = (float)W / (float)(H > 0 ? H : 1);
        float nx = 2.0f * px / W - 1.0f, ny = 1.0f - 2.0f * py / H;
        Vec3 d = normalize(fwd + right * (nx * th * aspect) + up * (ny * th));
        float best = 1e30f;
        int hit = -1;
        for (size_t i = 0; i < scene.objects.size(); i++) {
            float t;
            if (rayObject(scene.objects[i], eye, d, t) && t < best) { best = t; hit = (int)i; }
        }
        selected = hit;
    }

    // ---------- toque ----------
    bool hitUI(float x, float y) const {
        for (auto& r : rects)
            if (x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]) return true;
        return false;
    }

    int freeCount() const {
        int n = 0;
        for (auto& p : ptr) if (p.active && !p.ui) n++;
        return n;
    }

    float stickRadius() const { return 0.12f * (float)std::min(W, H); }

    void pDown(int id, float x, float y) {
        if (id < 0 || id >= 10) return;
        Ptr& p = ptr[id];
        p = Ptr();
        p.active = true;
        p.x = p.sx = x;
        p.y = p.sy = y;
        p.ui = hitUI(x, y);
        if (!p.ui && freeCount() > 1) multi = true;
    }

    void pMove(int id, float x, float y) {
        if (id < 0 || id >= 10 || !ptr[id].active) return;
        Ptr& p = ptr[id];
        p.dx = x - p.x; p.dy = y - p.y;
        p.x = x; p.y = y;
        p.moved += std::sqrt(p.dx * p.dx + p.dy * p.dy);
    }

    void endMove() {
        std::vector<int> ids;
        for (int i = 0; i < 10; i++) if (ptr[i].active && !ptr[i].ui) ids.push_back(i);
        if (!playing) {
            if (ids.size() == 1) {
                Ptr& p = ptr[ids[0]];
                yaw -= p.dx * 0.008f;
                pitch += p.dy * 0.008f;
                pitch = std::max(-1.5f, std::min(1.5f, pitch));
            } else if (ids.size() >= 2) {
                Ptr& a = ptr[ids[0]];
                Ptr& b = ptr[ids[1]];
                float cur = std::hypot(a.x - b.x, a.y - b.y);
                float prev = std::hypot((a.x - a.dx) - (b.x - b.dx), (a.y - a.dy) - (b.y - b.dy));
                if (cur > 1 && prev > 1) {
                    dist *= prev / cur;
                    dist = std::max(0.5f, std::min(100.0f, dist));
                }
                float mdx = (a.dx + b.dx) * 0.5f, mdy = (a.dy + b.dy) * 0.5f;
                Vec3 eye, fwd, right, up;
                camBasis(eye, fwd, right, up);
                float s = dist * 2.0f * std::tan(30.0f * kDeg2Rad) / (float)H;
                target -= right * (mdx * s);
                target += up * (mdy * s);
            }
        } else {
            bool stick = false;
            for (int id : ids) {
                Ptr& p = ptr[id];
                if (p.sx < W * 0.4f) {
                    float R = stickRadius();
                    stickX = std::max(-1.0f, std::min(1.0f, (p.x - p.sx) / R));
                    stickY = std::max(-1.0f, std::min(1.0f, (p.y - p.sy) / R));
                    stick = true;
                } else {
                    pYaw += p.dx * 0.005f;
                    pPitch -= p.dy * 0.005f;
                    pPitch = std::max(-1.5f, std::min(1.5f, pPitch));
                }
            }
            if (!stick) stickX = stickY = 0;
        }
        for (auto& p : ptr) { p.dx = 0; p.dy = 0; }
    }

    void pUp(int id, float x, float y) {
        if (id < 0 || id >= 10 || !ptr[id].active) return;
        Ptr& p = ptr[id];
        if (!playing && !p.ui && !multi && p.moved < 10.0f * dp) pick(x, y);
        if (playing && p.sx < W * 0.4f) stickX = stickY = 0;
        p = Ptr();
        if (freeCount() == 0) multi = false;
    }

    void cancel() {
        for (auto& p : ptr) p = Ptr();
        multi = false;
        stickX = stickY = 0;
    }

    // ---------- interface ----------
    void trackRect() {
        ImVec2 p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
        rects.push_back({p.x, p.y, s.x, s.y});
    }

    void ui() {
        ImGuiIO& io = ImGui::GetIO();
        W = (int)io.DisplaySize.x;
        H = (int)io.DisplaySize.y;
        rects.clear();
        if (!playing) editorUI(); else playUI();

        char buf[96];
        std::snprintf(buf, sizeof(buf), "%.0f FPS | %d objetos", io.Framerate, (int)scene.objects.size());
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        dl->AddText(ImVec2(10.0f * dp, H - 22.0f * dp), IM_COL32(230, 230, 230, 200), buf);
        if (!playing)
            dl->AddText(ImVec2(10.0f * dp, H - 42.0f * dp), IM_COL32(200, 200, 200, 160),
                        "1 dedo: orbitar | 2 dedos: zoom e mover | toque: selecionar");

        if (wantPlay) { wantPlay = false; startPlay(); }
        if (wantStop) { wantStop = false; stopPlay(); }
    }

    void editorUI() {
        const ImGuiWindowFlags fl = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings |
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse;

        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2((float)W, 0));
        ImGui::Begin("##bar", nullptr, fl);
        trackRect();
        barH = ImGui::GetWindowSize().y;

        if (ImGui::Button("Novo")) { scene.objects.clear(); selected = -1; scene.nextId = 1; status = "Cena nova"; }
        ImGui::SameLine();
        if (ImGui::Button("Salvar")) status = scene.save(savePath) ? "Cena salva" : "Erro ao salvar";
        ImGui::SameLine();
        if (ImGui::Button("Carregar")) { status = scene.load(savePath) ? "Cena carregada" : "Nada salvo"; selected = -1; }
        ImGui::SameLine();
        if (ImGui::Button("Painel")) showPanel = !showPanel;
        ImGui::SameLine();
        for (int s = 0; s < SHAPE_COUNT; s++) {
            std::string lbl = std::string("+") + kShapeName[s];
            if (ImGui::Button(lbl.c_str())) addObject(s);
            ImGui::SameLine();
        }
        bool has = selected >= 0 && selected < (int)scene.objects.size();
        if (!has) ImGui::BeginDisabled();
        if (ImGui::Button("Duplicar")) duplicateSelected();
        ImGui::SameLine();
        if (ImGui::Button("Excluir")) deleteSelected();
        if (!has) ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.55f, 0.2f, 1));
        if (ImGui::Button("PLAY")) wantPlay = true;
        ImGui::PopStyleColor();
        if (!status.empty()) { ImGui::SameLine(); ImGui::TextDisabled("%s", status.c_str()); }
        ImGui::End();

        if (!showPanel) return;
        float pw = W * 0.30f;
        ImGui::SetNextWindowPos(ImVec2(W - pw, barH));
        ImGui::SetNextWindowSize(ImVec2(pw, H - barH));
        ImGui::SetNextWindowBgAlpha(0.85f);
        ImGui::Begin("##panel", nullptr, fl & ~ImGuiWindowFlags_NoScrollbar);
        trackRect();
        ImGui::Text("Objetos (%d)", (int)scene.objects.size());
        ImGui::BeginChild("##lista", ImVec2(0, H * 0.22f), true);
        for (int i = 0; i < (int)scene.objects.size(); i++) {
            ImGui::PushID(i);
            if (ImGui::Selectable(scene.objects[i].name.c_str(), selected == i)) selected = i;
            ImGui::PopID();
        }
        ImGui::EndChild();

        if (selected >= 0 && selected < (int)scene.objects.size()) {
            Object& o = scene.objects[selected];
            ImGui::Separator();
            ImGui::Text("%s (%s)", o.name.c_str(), kShapeName[o.shape]);
            ImGui::PushItemWidth(-ImGui::GetFontSize() * 3.5f);
            ImGui::DragFloat3("Pos", &o.pos.x, 0.05f);
            ImGui::DragFloat3("Rot", &o.rot.x, 1.0f);
            ImGui::DragFloat3("Esc", &o.scl.x, 0.02f, 0.01f, 100.0f);
            ImGui::SliderFloat3("Cor", o.color, 0.0f, 1.0f);
            ImGui::PopItemWidth();
            ImGui::Text("Comportamento (Play)");
            ImGui::RadioButton("Nenhum", &o.behavior, BHV_NONE);
            ImGui::RadioButton("Girar", &o.behavior, BHV_SPIN);
            ImGui::RadioButton("Flutuar", &o.behavior, BHV_BOB);
        }
        ImGui::End();
    }

    void playUI() {
        ImGui::SetNextWindowPos(ImVec2(10, 10));
        ImGui::Begin("##play", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse);
        trackRect();
        if (ImGui::Button("Parar")) wantStop = true;
        ImGui::End();

        ImDrawList* dl = ImGui::GetForegroundDrawList();
        float R = stickRadius();
        for (auto& p : ptr) {
            if (!p.active || p.ui || p.sx >= W * 0.4f) continue;
            dl->AddCircle(ImVec2(p.sx, p.sy), R, IM_COL32(255, 255, 255, 120), 32, 3.0f);
            dl->AddCircleFilled(ImVec2(p.sx + stickX * R, p.sy + stickY * R), R * 0.35f, IM_COL32(255, 255, 255, 150));
        }
        dl->AddText(ImVec2(W * 0.5f - 120.0f * dp * 0.5f, 10), IM_COL32(255, 255, 255, 180),
                    "Esquerda: andar | Direita: olhar");
    }

    void render() {
        Mat4 vp = viewProj();
        rd.beginFrame(playing);
        if (!playing) rd.drawGrid(vp);
        rd.drawScene(playing ? play : scene, vp, playing ? -1 : selected);
    }
};
