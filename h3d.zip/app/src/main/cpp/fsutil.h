#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>

namespace fsu {

inline bool isDir(const std::string& p) {
    struct stat st;
    return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
inline bool exists(const std::string& p) {
    struct stat st;
    return lstat(p.c_str(), &st) == 0;
}
inline bool isSymlink(const std::string& p) {
    struct stat st;
    return lstat(p.c_str(), &st) == 0 && S_ISLNK(st.st_mode);
}
inline bool mkdirs(const std::string& p) {
    if (p.empty()) return false;
    if (isDir(p)) return true;
    std::string cur;
    size_t i = 0;
    if (p[0] == '/') { cur = "/"; i = 1; }
    for (; i <= p.size(); ++i) {
        if (i == p.size() || p[i] == '/') {
            if (!cur.empty() && !isDir(cur)) {
                if (mkdir(cur.c_str(), 0777) != 0 && errno != EEXIST) return false;
            }
        } else {
            cur += p[i];
        }
        if (i < p.size() && p[i] == '/' && cur.size() > 1 && cur.back() != '/') cur += '/';
    }
    return isDir(p);
}

// lista arquivos (dirsOnly=false) ou pastas (dirsOnly=true), ordenados
inline std::vector<std::string> list(const std::string& dir, bool dirsOnly = false) {
    std::vector<std::string> out;
    DIR* d = opendir(dir.c_str());
    if (!d) return out;
    while (dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n == "." || n == "..") continue;
        bool isd = isDir(dir + "/" + n);
        if (dirsOnly != isd) continue;
        out.push_back(n);
    }
    closedir(d);
    std::sort(out.begin(), out.end());
    return out;
}
inline bool readFile(const std::string& path, std::string& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}
inline bool writeFile(const std::string& path, const std::string& s) {
    const std::string temp = path + ".tmp";
    {
        std::ofstream f(temp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f.write(s.data(), (std::streamsize)s.size());
        if (!f) { f.close(); unlink(temp.c_str()); return false; }
    }
    if (rename(temp.c_str(), path.c_str()) != 0) {
        unlink(temp.c_str());
        return false;
    }
    return true;
}
inline void removeAll(const std::string& p) {
    // Não seguir links simbólicos para fora da pasta que está sendo removida.
    if (isSymlink(p)) { unlink(p.c_str()); return; }
    if (isDir(p)) {
        for (auto& n : list(p, true)) removeAll(p + "/" + n);
        for (auto& n : list(p, false)) unlink((p + "/" + n).c_str());
        rmdir(p.c_str());
    } else {
        unlink(p.c_str());
    }
}
inline bool copyFile(const std::string& src, const std::string& dst) {
    std::string data;
    if (!readFile(src, data)) return false;
    size_t slash = dst.find_last_of('/');
    if (slash != std::string::npos && !mkdirs(dst.substr(0, slash))) return false;
    return writeFile(dst, data);
}
inline bool copyDir(const std::string& src, const std::string& dst) {
    if (!isDir(src) || !mkdirs(dst)) return false;
    bool ok = true;
    for (const auto& n : list(src, false)) ok = copyFile(src + "/" + n, dst + "/" + n) && ok;
    for (const auto& n : list(src, true)) ok = copyDir(src + "/" + n, dst + "/" + n) && ok;
    return ok;
}

inline std::string ext(const std::string& name) {
    size_t d = name.rfind('.');
    if (d == std::string::npos) return "";
    std::string e = name.substr(d + 1);
    for (char& c : e) c = (char)std::tolower((unsigned char)c);
    return e;
}
inline std::string stem(const std::string& name) {
    size_t d = name.rfind('.');
    return d == std::string::npos ? name : name.substr(0, d);
}

}  // namespace fsu
